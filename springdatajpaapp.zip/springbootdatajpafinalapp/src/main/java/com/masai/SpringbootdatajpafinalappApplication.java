package com.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootdatajpafinalappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdatajpafinalappApplication.class, args);
	}

}
