package com.masai.service;

import com.masai.model.Course;
import com.masai.model.Student;

public interface CourseService {
	
	
	public Course registerNewCourse(Course course);
	

}
